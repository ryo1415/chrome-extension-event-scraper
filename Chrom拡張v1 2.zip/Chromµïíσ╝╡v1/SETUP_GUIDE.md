# Google Apps Script URL設定ガイド

## ステップ6: 拡張機能にURLを設定（詳細手順）

### 方法1: 設定画面を使用（推奨・簡単）

1. **拡張機能のアイコンをクリック**
   - ブラウザのツールバーにある拡張機能のアイコンをクリックします

2. **設定ボタンをクリック**
   - ポップアップの右上にある「⚙️」ボタンをクリックします

3. **URLを入力**
   - 「Google Apps ScriptのWebアプリURL」の入力欄に、手順5でコピーしたURLを貼り付けます
   - 例: `https://script.google.com/macros/s/AKfycby.../exec`

4. **保存ボタンをクリック**
   - 「保存」ボタンをクリックします
   - 「設定を保存しました！」というメッセージが表示されれば完了です

5. **動作確認**
   - 設定画面の「現在の設定」にURLが表示されていることを確認してください
   - 緑色で表示されていれば設定完了です

### 方法2: 開発者ツールを使用（上級者向け）

もし設定画面が表示されない場合や、直接設定したい場合は以下の方法を使用できます。

1. **拡張機能のアイコンをクリック**
   - ブラウザのツールバーにある拡張機能のアイコンをクリックします

2. **開発者ツールを開く**
   - Windows/Linux: `F12` キーを押す
   - Mac: `Cmd + Option + I` を押す
   - または、ポップアップを右クリックして「検証」を選択

3. **Consoleタブを開く**
   - 開発者ツールが開いたら、「Console」タブをクリックします

4. **以下のコマンドを実行**
   ```javascript
   localStorage.setItem('googleAppsScriptUrl', 'YOUR_SCRIPT_URL');
   ```
   `YOUR_SCRIPT_URL` の部分を、手順5でコピーした実際のURLに置き換えてください。
   
   例:
   ```javascript
   localStorage.setItem('googleAppsScriptUrl', 'https://script.google.com/macros/s/AKfycby1234567890/exec');
   ```

5. **Enterキーを押す**
   - コマンドを実行すると、何も表示されませんが、設定は保存されています

6. **確認**
   - 再度以下のコマンドを実行して、設定が保存されているか確認できます：
   ```javascript
   localStorage.getItem('googleAppsScriptUrl');
   ```
   - これでURLが表示されれば設定完了です

## トラブルシューティング

### 設定が保存されない場合

1. **URLの形式を確認**
   - URLは `https://script.google.com/macros/s/.../exec` の形式である必要があります
   - 末尾に `/exec` が含まれていることを確認してください

2. **ブラウザのキャッシュをクリア**
   - 拡張機能を再読み込みしてみてください
   - `chrome://extensions/` で拡張機能の「再読み込み」ボタンをクリック

3. **設定をクリアして再設定**
   - 設定画面で「クリア」ボタンをクリック
   - または、開発者ツールで以下を実行：
   ```javascript
   localStorage.removeItem('googleAppsScriptUrl');
   ```
   - その後、再度設定を行ってください

### 設定が正しく保存されているか確認する方法

開発者ツールのConsoleで以下を実行：
```javascript
localStorage.getItem('googleAppsScriptUrl');
```

URLが表示されれば設定完了です。`null` が表示される場合は設定されていません。

## 次のステップ

設定が完了したら：

1. こくちーずプロのイベント管理ページで情報を抽出
2. 「スプレッドシートに出力」ボタンをクリック
3. スプレッドシートを確認して、データがA2セル以降に追加されていることを確認

データが自動で追加されれば、設定は正常に完了しています！


