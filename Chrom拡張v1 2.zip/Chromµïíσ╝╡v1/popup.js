// ポップアップのロジック

document.addEventListener('DOMContentLoaded', () => {
  const extractBtn = document.getElementById('extractBtn');
  const copyBtn = document.getElementById('copyBtn');
  const resultDiv = document.getElementById('result');
  const errorDiv = document.getElementById('error');
  
  // 設定関連の要素
  const settingsBtn = document.getElementById('settingsBtn');
  const settingsDialog = document.getElementById('settingsDialog');
  const scriptUrlInput = document.getElementById('scriptUrlInput');
  const currentScriptUrl = document.getElementById('currentScriptUrl');
  const saveSettingsBtn = document.getElementById('saveSettingsBtn');
  const cancelSettingsBtn = document.getElementById('cancelSettingsBtn');
  const clearSettingsBtn = document.getElementById('clearSettingsBtn');
  
  // 設定画面の初期化
  function loadSettings() {
    const url = localStorage.getItem('googleAppsScriptUrl') || '';
    scriptUrlInput.value = url;
    currentScriptUrl.textContent = url || '未設定';
    if (url) {
      currentScriptUrl.style.color = '#4CAF50';
    } else {
      currentScriptUrl.style.color = '#666';
    }
  }
  
  // 設定画面を開く
  settingsBtn.addEventListener('click', () => {
    loadSettings();
    settingsDialog.style.display = 'flex';
  });
  
  // 設定を保存
  saveSettingsBtn.addEventListener('click', () => {
    const url = scriptUrlInput.value.trim();
    if (url && !url.includes('script.google.com')) {
      alert('正しいGoogle Apps ScriptのWebアプリURLを入力してください。\n例: https://script.google.com/macros/s/.../exec');
      return;
    }
    if (url) {
      localStorage.setItem('googleAppsScriptUrl', url);
      alert('設定を保存しました！');
    } else {
      localStorage.removeItem('googleAppsScriptUrl');
      alert('設定をクリアしました。');
    }
    loadSettings();
    settingsDialog.style.display = 'none';
  });
  
  // 設定画面を閉じる
  cancelSettingsBtn.addEventListener('click', () => {
    settingsDialog.style.display = 'none';
  });
  
  // 設定をクリア
  clearSettingsBtn.addEventListener('click', () => {
    if (confirm('設定をクリアしますか？')) {
      localStorage.removeItem('googleAppsScriptUrl');
      loadSettings();
      alert('設定をクリアしました。');
    }
  });
  
  // ダイアログの外側をクリックで閉じる
  settingsDialog.addEventListener('click', (e) => {
    if (e.target === settingsDialog) {
      settingsDialog.style.display = 'none';
    }
  });
  
  // 初期設定を読み込む
  loadSettings();

  // URLからイベントIDと日付IDを抽出
  function extractEventIds(url) {
    // URLパターン: /admin/e-{eventId}/d-{dateId}/ または /admin/participant/e-{eventId}/d-{dateId}/
    const match = url.match(/\/admin\/(?:participant\/)?e-([^\/]+)\/d-([^\/]+)/);
    if (match) {
      return {
        eventId: match[1],
        dateId: match[2]
      };
    }
    return null;
  }

  // 指定されたURLのタブで情報を取得
  function extractInfoFromTab(tabId) {
    return new Promise((resolve, reject) => {
      chrome.tabs.sendMessage(tabId, { action: 'extractInfo' }, (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        if (response && response.success) {
          resolve(response.data);
        } else {
          reject(new Error('情報の抽出に失敗しました'));
        }
      });
    });
  }

  extractBtn.addEventListener('click', async () => {
    try {
      // 現在のタブを取得
      const [currentTab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      // こくちーずプロの管理ページかチェック
      if (!currentTab.url.includes('kokuchpro.com/admin/')) {
        showError('こくちーずプロのイベント管理ページ（イベント状況または参加者管理）で使用してください。');
        return;
      }

      // ローディング表示
      extractBtn.disabled = true;
      extractBtn.textContent = '抽出中...';
      resultDiv.style.display = 'none';
      errorDiv.style.display = 'none';

      // イベントIDと日付IDを抽出
      const ids = extractEventIds(currentTab.url);
      if (!ids) {
        extractBtn.disabled = false;
        extractBtn.textContent = '情報を抽出';
        showError('URLからイベントIDを抽出できませんでした。');
        return;
      }

      // 両方のページのURLを生成
      const baseUrl = currentTab.url.match(/https?:\/\/[^\/]+/)[0];
      const eventStatusUrl = `${baseUrl}/admin/e-${ids.eventId}/d-${ids.dateId}/`;
      const participantUrl = `${baseUrl}/admin/participant/e-${ids.eventId}/d-${ids.dateId}/`;

      const result = {
        eventStatus: {},
        participant: {}
      };

      // 現在のページから情報を取得
      let currentPageExtractionError = null;
      try {
        const currentData = await extractInfoFromTab(currentTab.id);
        if (currentTab.url.includes('/admin/participant/')) {
          result.participant = currentData.participant || {};
          result.eventStatus = currentData.eventStatus || {};
        } else {
          result.eventStatus = currentData.eventStatus || {};
        }
      } catch (error) {
        currentPageExtractionError = error;
        const errorSummary = formatErrorForLog(error);
        console.error(
          '[extractInfoFromTab] 現在のページから情報を取得できませんでした。対象ページが開かれているか、拡張機能の権限を確認してください。',
          {
            tabId: currentTab.id,
            tabUrl: currentTab.url,
            reason: errorSummary,
            stack: error?.stack
          }
        );
      }

      // もう一方のページの情報を取得
      try {
        let otherTabId = null;
        let shouldCloseTab = false;
        const otherUrl = currentTab.url.includes('/admin/participant/') ? eventStatusUrl : participantUrl;
        
        // 既に開いているタブを探す
        const allTabs = await chrome.tabs.query({});
        const existingTab = allTabs.find(tab => tab.url === otherUrl);
        
        if (existingTab) {
          otherTabId = existingTab.id;
        } else {
          // 新しいタブを開く（バックグラウンドで）
          const newTab = await chrome.tabs.create({ url: otherUrl, active: false });
          otherTabId = newTab.id;
          shouldCloseTab = true;
          
          // ページが読み込まれるまで待つ
          await new Promise((resolve) => {
            const listener = (tabId, changeInfo) => {
              if (tabId === otherTabId && changeInfo.status === 'complete') {
                chrome.tabs.onUpdated.removeListener(listener);
                setTimeout(resolve, 1000); // 追加の待機時間
              }
            };
            chrome.tabs.onUpdated.addListener(listener);
          });
        }

        // もう一方のページから情報を取得
        const otherData = await extractInfoFromTab(otherTabId);
        
        if (currentTab.url.includes('/admin/participant/')) {
          // 現在が参加者管理ページの場合、イベント状況情報を取得
          result.eventStatus = { ...result.eventStatus, ...(otherData.eventStatus || {}) };
        } else {
          // 現在がイベント状況ページの場合、参加者情報を取得
          result.participant = otherData.participant || {};
          // 参加者管理ページにも基本情報がある場合
          if (otherData.eventStatus) {
            result.eventStatus = { ...result.eventStatus, ...otherData.eventStatus };
          }
        }

        // 新しく開いたタブを閉じる（既存のタブは閉じない）
        if (shouldCloseTab && otherTabId) {
          chrome.tabs.remove(otherTabId);
        }
      } catch (error) {
        console.error('もう一方のページからの情報取得エラー:', error);
        // エラーが発生しても、現在のページの情報は表示する
      }

      // 結果を表示
      extractBtn.disabled = false;
      extractBtn.textContent = '情報を抽出';
      displayInfo(result);
      resultDiv.style.display = 'block';
      if (currentPageExtractionError) {
        const reason = currentPageExtractionError?.message || formatErrorForLog(currentPageExtractionError);
        errorDiv.textContent = `現在のページから情報を取得できませんでした（${reason}）。ページを再読み込みしてから再実行してください。`;
        errorDiv.style.display = 'block';
      } else {
        errorDiv.style.display = 'none';
      }
      copyBtn.style.display = 'inline-block';
      document.getElementById('exportBtn').style.display = 'inline-block';
      
      // データをグローバル変数に保存（スプレッドシート出力用）
      window.currentEventData = result;

    } catch (error) {
      extractBtn.disabled = false;
      extractBtn.textContent = '情報を抽出';
      showError('エラーが発生しました: ' + error.message);
    }
  });

  copyBtn.addEventListener('click', () => {
    const text = formatInfoAsText();
    navigator.clipboard.writeText(text).then(() => {
      const originalText = copyBtn.textContent;
      copyBtn.textContent = 'コピーしました！';
      setTimeout(() => {
        copyBtn.textContent = originalText;
      }, 2000);
    }).catch(err => {
      showError('コピーに失敗しました: ' + err.message);
    });
  });

  // スプレッドシート出力ボタン
  const exportBtn = document.getElementById('exportBtn');
  exportBtn.addEventListener('click', async () => {
    if (!window.currentEventData) {
      showError('データがありません。先に情報を抽出してください。');
      return;
    }

    try {
      exportBtn.disabled = true;
      exportBtn.textContent = '出力中...';

      const data = prepareSpreadsheetData(window.currentEventData);
      await exportToSpreadsheet(data);

      exportBtn.textContent = '出力完了！';
      setTimeout(() => {
        exportBtn.textContent = 'スプレッドシートに出力';
        exportBtn.disabled = false;
      }, 2000);
    } catch (error) {
      exportBtn.disabled = false;
      exportBtn.textContent = 'スプレッドシートに出力';
      showError('スプレッドシートへの出力に失敗しました: ' + error.message);
    }
  });

  // スプレッドシート用のデータを準備
  function prepareSpreadsheetData(eventData) {
    const eventStatus = eventData.eventStatus || {};
    const participant = eventData.participant || {};

    // 開催日から開始時間と終了時間を抽出
    let startTime = '';
    let endTime = '';
    let eventDate = '';
    if (eventStatus.eventDate) {
      const dateMatch = eventStatus.eventDate.match(/(\d{4}年\d{1,2}月\d{1,2}日)\([日月火水木金土]\)\s+(\d{1,2}):(\d{2})〜(\d{1,2}):(\d{2})/);
      if (dateMatch) {
        eventDate = dateMatch[1].replace(/年|月|日/g, '/').replace(/\/$/, '');
        startTime = `${dateMatch[2]}:${dateMatch[3]}`;
        endTime = `${dateMatch[4]}:${dateMatch[5]}`;
      }
    }

    // 応募数と参加者数を抽出
    let applicationCount = '';
    let participantCount = '';
    if (eventStatus.entryCount) {
      const match = eventStatus.entryCount.match(/(\d+)\/(\d+)/);
      if (match) {
        participantCount = match[1];
        applicationCount = match[2];
      }
    } else if (participant.totalParticipants) {
      applicationCount = participant.totalParticipants.toString();
      participantCount = participant.totalParticipants.toString();
    }

    // キャンセル数を計算
    let cancelCount = 0;
    if (participant.participants) {
      cancelCount = participant.participants.filter(p => p.status && p.status.includes('キャンセル')).length;
    }

    // イベント売上から数値を抽出
    let salesAmount = '';
    if (eventStatus.totalSales) {
      const salesMatch = eventStatus.totalSales.match(/[¥￥]?([\d,]+)/);
      if (salesMatch) {
        salesAmount = salesMatch[1].replace(/,/g, '');
      }
    }

    // 曜日を抽出
    let dayOfWeek = '';
    if (eventStatus.eventDate) {
      const dayMatch = eventStatus.eventDate.match(/\(([日月火水木金土])\)/);
      if (dayMatch) {
        dayOfWeek = dayMatch[1];
      }
    }

    return [
      eventStatus.title || '',                    // A: イベント名
      '',                                         // B: プロジェクト
      eventStatus.eventType || '',                // C: イベント種別
      eventDate,                                  // D: 開催日
      startTime,                                  // E: 開始時間
      endTime,                                    // F: 終了時間
      dayOfWeek,                                  // G: 曜日
      '',                                         // H: 会場
      '',                                         // I: 担当者
      applicationCount,                           // J: 応募数
      participantCount,                           // K: 参加者数
      cancelCount.toString(),                     // L: キャンセル数
      '',                                         // M: 参加率
      '',                                         // N: キャンセル率
      '',                                         // O: キャンセル理由
      '',                                         // P: 集客経路
      '',                                         // Q: 告知媒体
      '',                                         // R: 参加費
      salesAmount,                                // S: イベント売上
      '',                                         // T: 経費
      '',                                         // U: 利益
      '',                                         // V: 必要工数
      '',                                         // W: 当日の流れ
      '',                                         // X: 満足度（自己）
      '',                                         // Y: 満足度（参加者）
      '',                                         // Z: 良かった点
      '',                                         // AA: 改善点
      '',                                         // AB: 原因分析
      '',                                         // AC: 改善アクション
      '',                                         // AD: アクション実施日
      '',                                         // AE: 次回仮説
      '',                                         // AF: 次回KPI
      ''                                          // AG: 成果
    ];
  }

  // Googleスプレッドシートにデータを出力
  async function exportToSpreadsheet(data) {
    const SPREADSHEET_ID = '1lrauuIdcRKUWbfXkz65fRDI9S4HyAvsJbf_OiAITeoU';
    const SCRIPT_URL = localStorage.getItem('googleAppsScriptUrl') || '';
    
    if (!SCRIPT_URL) {
      // URLが設定されていない場合はフォールバック
      const spreadsheetUrl = `https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/edit`;
      const tabSeparatedData = data.map(cell => {
        const cellValue = cell || '';
        return cellValue.toString().replace(/\t/g, ' ').replace(/\n/g, ' ');
      }).join('\t');
      
      await navigator.clipboard.writeText(tabSeparatedData);
      chrome.tabs.create({ url: spreadsheetUrl });
      alert('Google Apps ScriptのURLが設定されていません。\nデータをクリップボードにコピーしました。\nスプレッドシートのA2セルを選択して、Ctrl+V（Mac: Cmd+V）で貼り付けてください。\n\n自動出力を使用するには、設定ボタンからGoogle Apps ScriptのWebアプリURLを設定してください。');
      return;
    }
    
    // Apps ScriptのWebアプリを使用してデータを送信
    try {
      // URLの検証
      if (!SCRIPT_URL.includes('script.google.com')) {
        throw new Error('無効なURLです。Google Apps ScriptのWebアプリURLを設定してください。');
      }
      if (!SCRIPT_URL.includes('/exec')) {
        throw new Error('最新の公開URL（末尾が/exec）を設定してください。');
      }

      // データをPOST送信（text/plainにしてプリフライト回避）
      const response = await fetch(SCRIPT_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'text/plain;charset=utf-8'
        },
        body: JSON.stringify(data),
        cache: 'no-store',
        redirect: 'follow'
      });

      if (!response.ok) {
        throw new Error(`Apps Scriptへの送信に失敗しました (HTTP ${response.status})`);
      }

      // レスポンスを検証（Apps Script側でのエラーを検知する）
      let result = null;
      try {
        result = await response.json();
      } catch (err) {
        console.warn('Apps ScriptのレスポンスJSON解析に失敗しました', err);
      }

      if (result && result.success === false) {
        throw new Error(result.error || 'Apps Scriptからエラーが返されました');
      }

      alert('データを送信しました。\nスプレッドシートを確認してください。\n\n反映されない場合は、Google Apps Scriptの実行ログと権限設定を確認してください。');
      
      // スプレッドシートを開く
      const spreadsheetUrl = `https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/edit`;
      chrome.tabs.create({ url: spreadsheetUrl });
      
    } catch (error) {
      console.error('Apps Scriptへの送信エラー:', error);
      
      // エラーが発生した場合はフォールバック
      const spreadsheetUrl = `https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/edit`;
      const tabSeparatedData = data.map(cell => {
        const cellValue = cell || '';
        return cellValue.toString().replace(/\t/g, ' ').replace(/\n/g, ' ');
      }).join('\t');
      
      await navigator.clipboard.writeText(tabSeparatedData);
      chrome.tabs.create({ url: spreadsheetUrl });
      
      alert('自動送信に失敗しました。\nデータをクリップボードにコピーしました。\nスプレッドシートのA2セルを選択して、Ctrl+V（Mac: Cmd+V）で貼り付けてください。\n\nエラー: ' + error.message);
    }
  }

  function displayInfo(responseData) {
    // 新しいデータ構造に対応
    const eventStatus = responseData.eventStatus || {};
    const participant = responseData.participant || {};

    // 基本情報
    document.getElementById('title').textContent = eventStatus.title || '未設定';
    document.getElementById('description').textContent = eventStatus.description || '未設定';
    document.getElementById('eventDate').textContent = eventStatus.eventDate || '未設定';
    
    // すべての開催日情報
    const allDatesContainer = document.getElementById('allDatesContainer');
    const allDatesDiv = document.getElementById('allEventDates');
    if (eventStatus.allEventDates && eventStatus.allEventDates.length > 0) {
      allDatesContainer.style.display = 'flex';
      allDatesDiv.innerHTML = eventStatus.allEventDates.map((dateInfo, index) => `
        <div class="date-item" style="margin: 5px 0; padding: 5px; background: #f0f0f0; border-radius: 3px;">
          <strong>${index + 1}. ${dateInfo.date}</strong> (${dateInfo.status})
        </div>
      `).join('');
    } else {
      allDatesContainer.style.display = 'none';
    }
    
    const eventUrlEl = document.getElementById('eventUrl');
    eventUrlEl.textContent = eventStatus.eventUrl || '未設定';
    eventUrlEl.href = eventStatus.eventUrl || '#';
    
    const shortUrlEl = document.getElementById('shortUrl');
    shortUrlEl.textContent = eventStatus.shortUrl || '未設定';
    shortUrlEl.href = eventStatus.shortUrl || '#';

    // イベント状況
    document.getElementById('eventStatus').textContent = eventStatus.eventStatus || '未設定';
    document.getElementById('recruitmentPeriod').textContent = eventStatus.recruitmentPeriod || '未設定';
    document.getElementById('eventType').textContent = eventStatus.eventType || '未設定';
    document.getElementById('pricingType').textContent = eventStatus.pricingType || '未設定';
    document.getElementById('paymentMethod').textContent = eventStatus.paymentMethod || '未設定';
    document.getElementById('paymentEmail').textContent = eventStatus.paymentEmail || '未設定';
    document.getElementById('publicMode').textContent = eventStatus.publicMode || '未設定';
    document.getElementById('eventGrade').textContent = eventStatus.eventGrade || '未設定';

    // 申込状況
    document.getElementById('entryCount').textContent = eventStatus.entryCount || '未設定';
    document.getElementById('entryStatus').textContent = eventStatus.entryStatus || '未設定';
    document.getElementById('totalSales').textContent = eventStatus.totalSales || '未設定';

    // チケット情報
    const ticketsDiv = document.getElementById('tickets');
    if (eventStatus.tickets && eventStatus.tickets.length > 0) {
      ticketsDiv.innerHTML = eventStatus.tickets.map((ticket, index) => `
        <div class="ticket-item">
          <h3>チケット ${index + 1}</h3>
          <div class="info-item">
            <label>チケット名:</label>
            <span>${ticket.name}</span>
          </div>
          <div class="info-item">
            <label>金額:</label>
            <span>${ticket.price}</span>
          </div>
          <div class="info-item">
            <label>申込数:</label>
            <span>${ticket.entryCount}</span>
          </div>
          <div class="info-item">
            <label>状態:</label>
            <span>${ticket.status}</span>
          </div>
          ${ticket.endDate ? `<div class="info-item"><label>締切日:</label><span>${ticket.endDate}</span></div>` : ''}
        </div>
      `).join('');
    } else {
      ticketsDiv.innerHTML = '<p>チケット情報が見つかりませんでした。</p>';
    }

    // 参加者情報
    const participantSection = document.getElementById('participantSection');
    const participantsList = document.getElementById('participantsList');
    if (participant.participants && participant.participants.length > 0) {
      participantSection.style.display = 'block';
      document.getElementById('totalParticipants').textContent = participant.totalParticipants || participant.participants.length;
      
      participantsList.innerHTML = participant.participants.map((p, index) => `
        <div class="participant-item" style="margin: 10px 0; padding: 10px; background: white; border-radius: 4px; border: 1px solid #e0e0e0;">
          <h4 style="margin: 0 0 8px 0; color: #4CAF50;">${index + 1}. ${p.name || '未設定'}</h4>
          <div class="info-item">
            <label>申込番号:</label>
            <span>${p.entryNumber}</span>
          </div>
          <div class="info-item">
            <label>申込状態:</label>
            <span>${p.status}</span>
          </div>
          <div class="info-item">
            <label>メールアドレス:</label>
            <span>${p.email}</span>
          </div>
          <div class="info-item">
            <label>イベント申込数:</label>
            <span>${p.eventEntryCount}</span>
          </div>
          <div class="info-item">
            <label>懇親会申込数:</label>
            <span>${p.partyEntryCount}</span>
          </div>
          <div class="info-item">
            <label>申込日時:</label>
            <span>${p.entryDateTime}</span>
          </div>
        </div>
      `).join('');
    } else {
      participantSection.style.display = 'none';
    }
  }

  function formatInfoAsText() {
    const data = {};
    data.title = document.getElementById('title').textContent;
    data.description = document.getElementById('description').textContent;
    data.eventDate = document.getElementById('eventDate').textContent;
    data.eventUrl = document.getElementById('eventUrl').href;
    data.shortUrl = document.getElementById('shortUrl').href;
    data.eventStatus = document.getElementById('eventStatus').textContent;
    data.recruitmentPeriod = document.getElementById('recruitmentPeriod').textContent;
    data.eventType = document.getElementById('eventType').textContent;
    data.pricingType = document.getElementById('pricingType').textContent;
    data.paymentMethod = document.getElementById('paymentMethod').textContent;
    data.paymentEmail = document.getElementById('paymentEmail').textContent;
    data.publicMode = document.getElementById('publicMode').textContent;
    data.eventGrade = document.getElementById('eventGrade').textContent;
    data.entryCount = document.getElementById('entryCount').textContent;
    data.entryStatus = document.getElementById('entryStatus').textContent;
    data.totalSales = document.getElementById('totalSales').textContent;

    let text = '=== イベント情報 ===\n\n';
    text += `タイトル: ${data.title}\n`;
    text += `説明: ${data.description}\n`;
    text += `開催日: ${data.eventDate}\n`;
    text += `イベントURL: ${data.eventUrl}\n`;
    text += `短縮URL: ${data.shortUrl}\n\n`;
    text += `イベント状態: ${data.eventStatus}\n`;
    text += `募集期間: ${data.recruitmentPeriod}\n`;
    text += `イベント形態: ${data.eventType}\n`;
    text += `料金制度: ${data.pricingType}\n`;
    text += `支払方法: ${data.paymentMethod}\n`;
    text += `支払先メール: ${data.paymentEmail}\n`;
    text += `公開モード: ${data.publicMode}\n`;
    text += `イベントグレード: ${data.eventGrade}\n\n`;
    text += `申込数: ${data.entryCount}\n`;
    text += `申込状態: ${data.entryStatus}\n`;
    text += `販売金額: ${data.totalSales}\n`;

    // 参加者情報があれば追加
    const participantSection = document.getElementById('participantSection');
    if (participantSection.style.display !== 'none') {
      const totalParticipants = document.getElementById('totalParticipants').textContent;
      text += `\n=== 参加者情報 ===\n\n`;
      text += `総参加者数: ${totalParticipants}\n\n`;
      
      const participants = participantSection.querySelectorAll('.participant-item');
      participants.forEach((item, index) => {
        const name = item.querySelector('h4')?.textContent.replace(/^\d+\.\s*/, '') || '';
        const entryNumber = item.querySelectorAll('.info-item')[0]?.querySelector('span')?.textContent || '';
        const status = item.querySelectorAll('.info-item')[1]?.querySelector('span')?.textContent || '';
        const email = item.querySelectorAll('.info-item')[2]?.querySelector('span')?.textContent || '';
        const eventEntryCount = item.querySelectorAll('.info-item')[3]?.querySelector('span')?.textContent || '';
        const partyEntryCount = item.querySelectorAll('.info-item')[4]?.querySelector('span')?.textContent || '';
        const entryDateTime = item.querySelectorAll('.info-item')[5]?.querySelector('span')?.textContent || '';
        
        text += `参加者 ${index + 1}:\n`;
        text += `  名前: ${name}\n`;
        text += `  申込番号: ${entryNumber}\n`;
        text += `  申込状態: ${status}\n`;
        text += `  メールアドレス: ${email}\n`;
        text += `  イベント申込数: ${eventEntryCount}\n`;
        text += `  懇親会申込数: ${partyEntryCount}\n`;
        text += `  申込日時: ${entryDateTime}\n\n`;
      });
    }

    return text;
  }

  function showError(message) {
    errorDiv.textContent = message;
    errorDiv.style.display = 'block';
    resultDiv.style.display = 'none';
  }

  function formatErrorForLog(error) {
    if (!error) return '不明なエラー';
    if (error instanceof Error) return `${error.name}: ${error.message}`;
    if (typeof error === 'string') return error;
    try {
      return JSON.stringify(error);
    } catch {
      return String(error);
    }
  }
});
