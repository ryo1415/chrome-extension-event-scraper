// こくちーずプロのイベント管理ページから情報を抽出

// ページ全体をスクロールしてすべての要素を読み込む
async function scrollPageToLoadAll() {
  return new Promise((resolve) => {
    let lastHeight = document.body.scrollHeight;
    let scrollAttempts = 0;
    const maxAttempts = 10;

    const scrollInterval = setInterval(() => {
      window.scrollTo(0, document.body.scrollHeight);
      scrollAttempts++;

      setTimeout(() => {
        const newHeight = document.body.scrollHeight;
        if (newHeight === lastHeight || scrollAttempts >= maxAttempts) {
          clearInterval(scrollInterval);
          // ページの先頭に戻る
          window.scrollTo(0, 0);
          setTimeout(resolve, 500);
        } else {
          lastHeight = newHeight;
        }
      }, 300);
    }, 300);
  });
}

// テーブルから情報を取得するヘルパー関数
function getTableData(table) {
  const data = {};
  if (!table) return data;

  const rows = table.querySelectorAll('tr');
  rows.forEach(row => {
    const th = row.querySelector('th');
    const td = row.querySelector('td');
    if (th && td) {
      const key = th.textContent.trim();
      const value = td.textContent.trim();
      data[key] = value;
    }
  });
  return data;
}

// テーブルを内容で識別して取得
function findTableByContent(tables, searchText) {
  for (const table of tables) {
    const text = table.textContent;
    if (text.includes(searchText)) {
      return table;
    }
  }
  return null;
}

// 参加者管理ページから情報を抽出
function extractParticipantInfo() {
  const info = {
    participants: [],
    totalParticipants: 0
  };

  // イベント申込数の取得
  const entryCountText = document.querySelector('.col-xs-12.col-lg-4')?.textContent;
  if (entryCountText && entryCountText.includes('イベント申込数:')) {
    const match = entryCountText.match(/イベント申込数:\s*(\d+)/);
    if (match) {
      info.totalParticipants = parseInt(match[1], 10);
    }
  }

  // 参加者テーブルの取得
  const participantTable = document.querySelector('table.table-condensed.table-bordered');
  if (participantTable) {
    const rows = participantTable.querySelectorAll('tr');
    rows.forEach((row, index) => {
      if (index === 0) return; // ヘッダー行をスキップ
      
      const cells = row.querySelectorAll('td');
      if (cells.length >= 6) {
        // 申込番号
        const entryNumberLink = cells[0].querySelector('a');
        const entryNumber = entryNumberLink ? entryNumberLink.textContent.trim() : cells[0].textContent.trim();
        const entryNumberUrl = entryNumberLink ? entryNumberLink.href : '';
        
        // 申込状態
        const statusLabel = cells[1].querySelector('.label');
        const status = statusLabel ? statusLabel.textContent.trim() : cells[1].textContent.trim();
        
        // 参加者情報（名前とメール）
        const participantCell = cells[2];
        const nameElement = participantCell.querySelector('strong');
        const name = nameElement ? nameElement.textContent.trim() : '';
        const email = participantCell.textContent.replace(name, '').trim();
        
        // イベント申込数
        const eventEntryCount = cells[3].textContent.trim();
        
        // 懇親会申込数
        const partyEntryCount = cells[4].textContent.trim();
        
        // 申込日時
        const entryDateTime = cells[5].textContent.trim();
        
        info.participants.push({
          entryNumber: entryNumber,
          entryNumberUrl: entryNumberUrl,
          status: status,
          name: name,
          email: email,
          eventEntryCount: eventEntryCount,
          partyEntryCount: partyEntryCount,
          entryDateTime: entryDateTime
        });
      }
    });
  }

  return info;
}

// イベント状況ページから情報を抽出
function extractEventStatusInfo() {
  const info = {};

  // イベントタイトル（より堅牢なセレクタ）
  const titleElement = document.querySelector('h2.admin_event_title a') || 
                       document.querySelector('h2.admin_event_title');
  info.title = titleElement ? titleElement.textContent.trim() : '';

  // イベント説明（複数の方法で取得を試みる）
  let descriptionElement = document.querySelector('h2.admin_event_title')?.nextElementSibling;
  if (!descriptionElement || descriptionElement.tagName !== 'P') {
    // 別の方法で取得を試みる
    const titleParent = document.querySelector('h2.admin_event_title')?.parentElement;
    if (titleParent) {
      descriptionElement = titleParent.querySelector('p');
    }
  }
  info.description = descriptionElement ? descriptionElement.textContent.trim() : '';

  // イベントURL（すべての該当するinputを取得）
  const urlInputs = Array.from(document.querySelectorAll('input.form-control.click-text-select'))
    .filter(input => input.value && input.value.includes('kokuchpro.com'));
  info.eventUrl = urlInputs[0] ? urlInputs[0].value.trim() : '';
  info.shortUrl = urlInputs[1] ? urlInputs[1].value.trim() : '';

  // すべてのテーブルを取得（表示されていないものも含む）
  const allTables = Array.from(document.querySelectorAll('table.table-condensed.table-bordered'));
  const allBorderedTables = Array.from(document.querySelectorAll('table.table-bordered'));

  // イベント状況テーブル（「イベント開催まで」を含むテーブル）
  const statusTable = findTableByContent(allTables, 'イベント開催まで') || allTables[0];
  if (statusTable) {
    const statusData = getTableData(statusTable);
    info.eventStatus = statusData['イベント開催まで'] || '';
    info.recruitmentPeriod = statusData['募集期間'] || '';
    info.eventType = statusData['イベント形態'] || '';
    info.pricingType = statusData['料金制度'] || '';
    info.paymentMethod = (statusData['支払方法'] || '').replace(/\s+/g, ' ').trim();
    info.paymentEmail = statusData['こくちーず決済支払先'] || '';
    info.receptionType = statusData['受付タイプ'] || '';
    info.publicMode = statusData['公開モード'] || '';
    info.eventState = statusData['イベント状態'] || '';
    
    // イベントグレード（リンクテキストを取得）
    const gradeRow = Array.from(statusTable.querySelectorAll('tr')).find(row => {
      const th = row.querySelector('th');
      return th && th.textContent.trim() === 'イベントグレード';
    });
    if (gradeRow) {
      const gradeLink = gradeRow.querySelector('td a');
      info.eventGrade = gradeLink ? gradeLink.textContent.trim() : 
                       (gradeRow.querySelector('td')?.textContent.trim() || '');
    }
  }

  // 申込状況テーブル（「イベント申込」を含むテーブル）
  const entryTable = findTableByContent(allTables, 'イベント申込') || allTables[1];
  if (entryTable) {
    const entryData = getTableData(entryTable);
    // 申込数の詳細を取得
    const entryRow = Array.from(entryTable.querySelectorAll('tr')).find(row => {
      const th = row.querySelector('th');
      return th && th.textContent.trim() === 'イベント申込';
    });
    if (entryRow) {
      const entryCounter = entryRow.querySelector('.entry_counter');
      if (entryCounter) {
        const entryCount = entryCounter.querySelector('.entry_count')?.textContent.trim() || '0';
        const totalCount = entryCounter.querySelector('.total_count')?.textContent.trim() || '0';
        info.entryCount = `${entryCount}/${totalCount}`;
      } else {
        info.entryCount = entryData['イベント申込'] || '';
      }
    }
    info.entryStatus = entryData['申込状態'] || '';
  }

  // チケット販売金額テーブル（「イベント」を含むテーブル）
  const salesTable = findTableByContent(allTables, 'イベント') || allTables[2];
  if (salesTable) {
    const salesData = getTableData(salesTable);
    info.totalSales = salesData['イベント'] || '';
  }

  // チケット情報（すべてのtable-borderedから取得）
  info.tickets = [];
  const ticketTable = findTableByContent(allBorderedTables, 'チケット名') || 
                      allBorderedTables.find(table => {
                        const headers = Array.from(table.querySelectorAll('th'));
                        return headers.some(th => th.textContent.includes('チケット名'));
                      });
  
  if (ticketTable) {
    const rows = ticketTable.querySelectorAll('tr');
    rows.forEach((row, index) => {
      if (index === 0) return; // ヘッダー行をスキップ
      
      const cells = row.querySelectorAll('td');
      if (cells.length >= 4) {
        const ticketName = cells[0].textContent.trim();
        const price = cells[1].textContent.trim();
        const entryInfo = cells[2].textContent.trim();
        const status = cells[3].textContent.trim();
        
        // 締切日の抽出
        const endDateElement = cells[0].querySelector('.seat_end_date');
        const endDate = endDateElement ? endDateElement.textContent.trim() : '';
        
        info.tickets.push({
          name: ticketName.replace(endDate, '').trim(),
          price: price,
          entryCount: entryInfo,
          status: status,
          endDate: endDate
        });
      }
    });
  }

  // 開催日情報（select要素から、すべてのオプションも取得）
  const dateSelect = document.querySelector('select.select-control.select-link') ||
                     document.querySelector('select.select-control');
  if (dateSelect) {
    const selectedOption = dateSelect.options[dateSelect.selectedIndex];
    if (selectedOption) {
      const dateText = selectedOption.textContent.trim();
      const dateMatch = dateText.match(/(\d{4}年\d{1,2}月\d{1,2}日\([日月火水木金土]\)\s+\d{1,2}:\d{2}〜\d{1,2}:\d{2})/);
      if (dateMatch) {
        info.eventDate = dateMatch[1];
      }
      const statusMatch = dateText.match(/^（(.+?)）/);
      if (statusMatch) {
        info.dateStatus = statusMatch[1];
      }
    }
    
    // すべての開催日オプションも保存
    info.allEventDates = [];
    Array.from(dateSelect.options).forEach(option => {
      if (option.value && !option.value.includes('#')) {
        const dateText = option.textContent.trim();
        const dateMatch = dateText.match(/(\d{4}年\d{1,2}月\d{1,2}日\([日月火水木金土]\)\s+\d{1,2}:\d{2}〜\d{1,2}:\d{2})/);
        if (dateMatch) {
          const statusMatch = dateText.match(/^（(.+?)）/);
          info.allEventDates.push({
            date: dateMatch[1],
            status: statusMatch ? statusMatch[1] : '',
            url: option.getAttribute('data-href') || ''
          });
        }
      }
    });
  }

  return info;
}

// メインの情報抽出関数（ページタイプを判定）
function extractEventInfo() {
  const currentUrl = window.location.href;
  const isParticipantPage = currentUrl.includes('/admin/participant/');
  const isEventStatusPage = currentUrl.includes('/admin/e-') && !currentUrl.includes('/admin/participant/');
  
  const result = {
    pageType: isParticipantPage ? 'participant' : (isEventStatusPage ? 'eventStatus' : 'unknown'),
    eventStatus: {},
    participant: {}
  };

  // イベント状況ページの情報を抽出
  if (isEventStatusPage) {
    result.eventStatus = extractEventStatusInfo();
  }

  // 参加者管理ページの情報を抽出
  if (isParticipantPage) {
    result.participant = extractParticipantInfo();
    // 参加者管理ページにも基本情報がある場合、それも取得
    const titleElement = document.querySelector('h2.admin_event_title a') || 
                         document.querySelector('h2.admin_event_title');
    if (titleElement) {
      result.eventStatus.title = titleElement.textContent.trim();
    }
    const descriptionElement = document.querySelector('h2.admin_event_title')?.nextElementSibling;
    if (descriptionElement && descriptionElement.tagName === 'P') {
      result.eventStatus.description = descriptionElement.textContent.trim();
    }
  }

  return result;
}

// メッセージリスナーで情報抽出リクエストを処理
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'extractInfo') {
    // ページをスクロールしてすべての要素を読み込んでから抽出
    scrollPageToLoadAll().then(() => {
      const info = extractEventInfo();
      sendResponse({ success: true, data: info });
    });
    return true; // 非同期レスポンスのため
  }
  return true;
});


