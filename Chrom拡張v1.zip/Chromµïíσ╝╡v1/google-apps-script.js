/**
 * Google Apps Script コード
 * 
 * このコードをGoogle Apps Scriptにコピーして、Webアプリとして公開してください。
 * 
 * 手順：
 * 1. https://script.google.com/ にアクセス
 * 2. 新しいプロジェクトを作成
 * 3. このコードをコピー＆ペースト
 * 4. 「公開」→「ウェブアプリとして導入」を選択
 * 5. 実行ユーザーを「自分」に設定
 * 6. アクセス権限を「全員（匿名ユーザーを含む）」に設定
 * 7. 「導入」をクリック
 * 8. 表示されたWebアプリのURLをコピー
 * 9. popup.jsのSCRIPT_URLにそのURLを設定
 */

function doPost(e) {
  try {
    const spreadsheetId = '1lrauuIdcRKUWbfXkz65fRDI9S4HyAvsJbf_OiAITeoU';
    
    // スプレッドシートを開く
    const spreadsheet = SpreadsheetApp.openById(spreadsheetId);
    const sheet = spreadsheet.getActiveSheet();
    
    // POSTデータから配列を取得
    let data;
    if (e.postData && e.postData.contents) {
      data = JSON.parse(e.postData.contents);
    } else if (e.parameter && e.parameter.data) {
      data = JSON.parse(e.parameter.data);
    } else {
      throw new Error('データが送信されていません');
    }
    
    // データが配列であることを確認
    if (!Array.isArray(data)) {
      throw new Error('データが配列形式ではありません: ' + typeof data);
    }
    
    // 最後の行を取得（ヘッダー行がある場合は2行目から開始）
    const lastRow = sheet.getLastRow();
    const targetRow = lastRow >= 1 ? lastRow + 1 : 2;
    
    // データを書き込む（AG列まで = 33列）
    const numColumns = Math.min(data.length, 33); // AG列は33列目
    const range = sheet.getRange(targetRow, 1, 1, numColumns);
    
    // データを2次元配列に変換
    const values = [data.slice(0, numColumns)];
    range.setValues(values);
    
    // ログに記録（デバッグ用）
    Logger.log('データを追加しました: 行 ' + targetRow);
    Logger.log('データ: ' + JSON.stringify(data));
    
    return ContentService.createTextOutput(JSON.stringify({
      success: true,
      message: 'データが正常に追加されました',
      row: targetRow,
      dataLength: data.length
    })).setMimeType(ContentService.MimeType.JSON);
    
  } catch (error) {
    // エラーをログに記録
    Logger.log('エラー: ' + error.toString());
    Logger.log('スタック: ' + error.stack);
    
    return ContentService.createTextOutput(JSON.stringify({
      success: false,
      error: error.toString(),
      stack: error.stack
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet(e) {
  try {
    // GETリクエストでもデータを受け取れるようにする（CORS回避のため）
    const spreadsheetId = '1lrauuIdcRKUWbfXkz65fRDI9S4HyAvsJbf_OiAITeoU';
    const spreadsheet = SpreadsheetApp.openById(spreadsheetId);
    const sheet = spreadsheet.getActiveSheet();
    
    let data;
    if (e.parameter && e.parameter.data) {
      data = JSON.parse(e.parameter.data);
    } else {
      return ContentService.createTextOutput('データパラメータが必要です。')
        .setMimeType(ContentService.MimeType.TEXT);
    }
    
    // データが配列であることを確認
    if (!Array.isArray(data)) {
      throw new Error('データが配列形式ではありません: ' + typeof data);
    }
    
    // 最後の行を取得
    const lastRow = sheet.getLastRow();
    const targetRow = lastRow >= 1 ? lastRow + 1 : 2;
    
    // データを書き込む
    const numColumns = Math.min(data.length, 33);
    const range = sheet.getRange(targetRow, 1, 1, numColumns);
    const values = [data.slice(0, numColumns)];
    range.setValues(values);
    
    // ログに記録
    Logger.log('GETリクエストでデータを追加しました: 行 ' + targetRow);
    
    return ContentService.createTextOutput(JSON.stringify({
      success: true,
      message: 'データが正常に追加されました',
      row: targetRow
    })).setMimeType(ContentService.MimeType.JSON);
    
  } catch (error) {
    Logger.log('GETエラー: ' + error.toString());
    return ContentService.createTextOutput(JSON.stringify({
      success: false,
      error: error.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  }
}


